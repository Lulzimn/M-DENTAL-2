import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Smile, 
  Shield, 
  Zap, 
  Heart, 
  Sparkles, 
  Stethoscope,
  CheckCircle,
  Star
} from 'lucide-react';

export default function ServicesSection() {
  const services = [
    {
      icon: <Shield className="h-8 w-8" />,
      title: "Preventive Care",
      description: "Regular checkups, cleanings, and preventive treatments to maintain optimal oral health.",
      features: ["Regular Checkups", "Professional Cleaning", "Fluoride Treatment", "Oral Health Education"],
      popular: false
    },
    {
      icon: <Smile className="h-8 w-8" />,
      title: "General Dentistry",
      description: "Comprehensive dental care including fillings, crowns, and basic restorative procedures.",
      features: ["Dental Fillings", "Crowns & Bridges", "Tooth Extraction", "Root Canal Treatment"],
      popular: true
    },
    {
      icon: <Sparkles className="h-8 w-8" />,
      title: "Cosmetic Dentistry",
      description: "Enhance your smile with professional cosmetic dental treatments and procedures.",
      features: ["Teeth Whitening", "Veneers", "Smile Makeover", "Aesthetic Restorations"],
      popular: false
    },
    {
      icon: <Zap className="h-8 w-8" />,
      title: "Oral Surgery",
      description: "Specialized surgical procedures performed with precision and care for optimal results.",
      features: ["Tooth Extraction", "Wisdom Teeth Removal", "Dental Implants", "Oral Pathology"],
      popular: false
    },
    {
      icon: <Heart className="h-8 w-8" />,
      title: "Restorative Dentistry",
      description: "Restore damaged or missing teeth to full function and natural appearance.",
      features: ["Dental Implants", "Dentures", "Bridges", "Comprehensive Restoration"],
      popular: true
    },
    {
      icon: <Stethoscope className="h-8 w-8" />,
      title: "Consultation & Care",
      description: "Professional consultation and comprehensive oral health assessment for all patients.",
      features: ["Oral Health Assessment", "Treatment Planning", "Follow-up Care", "Patient Education"],
      popular: false
    }
  ];

  return (
    <section id="services" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Dental Services</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We provide comprehensive dental care services to meet all your oral health needs. 
            From routine checkups to advanced procedures, our experienced team is here to help.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card key={index} className={`relative overflow-hidden hover:shadow-lg transition-all duration-300 ${
              service.popular ? 'ring-2 ring-blue-600 transform hover:scale-105' : 'hover:transform hover:scale-105'
            }`}>
              {service.popular && (
                <div className="absolute top-4 right-4">
                  <Badge className="bg-blue-600 hover:bg-blue-700">
                    <Star className="h-3 w-3 mr-1" />
                    Popular
                  </Badge>
                </div>
              )}
              
              <CardHeader className="pb-4">
                <div className={`w-16 h-16 rounded-full flex items-center justify-center mb-4 ${
                  service.popular ? 'bg-blue-600 text-white' : 'bg-blue-100 text-blue-600'
                }`}>
                  {service.icon}
                </div>
                <CardTitle className="text-xl text-gray-900">{service.title}</CardTitle>
              </CardHeader>
              
              <CardContent className="pt-0">
                <p className="text-gray-600 mb-6">{service.description}</p>
                
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900 text-sm">What's Included:</h4>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center gap-2 text-sm text-gray-600">
                        <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 text-center">
          <Card className="max-w-4xl mx-auto bg-gradient-to-r from-blue-50 to-indigo-50">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Quality Care You Can Trust</h3>
              <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
                All our services are performed by experienced doctors DR. Rilind Ramadani and DR. Mevlude R. Nuredini 
                with over 5 years of professional experience in modern dental care.
              </p>
              <div className="grid md:grid-cols-3 gap-6 text-center">
                <div>
                  <div className="text-3xl font-bold text-blue-600 mb-2">5+</div>
                  <div className="text-sm text-gray-600">Years Experience</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-blue-600 mb-2">100%</div>
                  <div className="text-sm text-gray-600">Professional Care</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-blue-600 mb-2">Mon-Fri</div>
                  <div className="text-sm text-gray-600">Available Hours</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}