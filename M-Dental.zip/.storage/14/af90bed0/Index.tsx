import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import DoctorsSection from '@/components/DoctorsSection';
import ServicesSection from '@/components/ServicesSection';
import AppointmentForm from '@/components/AppointmentForm';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';

export default function Index() {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <HeroSection />
        <DoctorsSection />
        <ServicesSection />
        <AppointmentForm />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}