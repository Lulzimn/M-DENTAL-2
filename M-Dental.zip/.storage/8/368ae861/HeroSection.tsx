import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Star, Award, Users, Clock } from 'lucide-react';

export default function HeroSection() {
  const scrollToAppointment = () => {
    const element = document.getElementById('appointment');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="bg-gradient-to-br from-blue-50 to-white py-20">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 leading-tight">
                Your Smile is Our
                <span className="text-blue-600 block">Priority</span>
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed">
                Professional dental care in Bogovinje with experienced doctors providing 
                comprehensive oral health services for you and your family.
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
              <Button 
                size="lg" 
                className="bg-blue-600 hover:bg-blue-700 px-8"
                onClick={scrollToAppointment}
              >
                Book Appointment
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => document.getElementById('doctors')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Meet Our Doctors
              </Button>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-8">
              <Card className="p-4 text-center">
                <Award className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">5+</div>
                <div className="text-sm text-gray-600">Years Experience</div>
              </Card>
              <Card className="p-4 text-center">
                <Users className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">2</div>
                <div className="text-sm text-gray-600">Expert Doctors</div>
              </Card>
              <Card className="p-4 text-center">
                <Star className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">100%</div>
                <div className="text-sm text-gray-600">Professional</div>
              </Card>
              <Card className="p-4 text-center">
                <Clock className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">10h</div>
                <div className="text-sm text-gray-600">Daily Service</div>
              </Card>
            </div>
          </div>

          <div className="relative">
            <div className="bg-gradient-to-br from-blue-100 to-blue-200 rounded-3xl p-8 transform rotate-3">
              <div className="bg-white rounded-2xl p-8 transform -rotate-3 shadow-xl">
                <div className="text-center space-y-4">
                  <div className="w-20 h-20 bg-blue-600 rounded-full mx-auto flex items-center justify-center">
                    <span className="text-2xl font-bold text-white">M</span>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900">M-Dental</h3>
                  <p className="text-gray-600">Professional Dental Care</p>
                  <div className="flex justify-center">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-sm text-gray-500">Trusted by our community</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}