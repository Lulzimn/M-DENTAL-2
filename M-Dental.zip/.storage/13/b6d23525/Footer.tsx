import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Heart,
  Star,
  Shield,
  Award
} from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-900 text-white">
      {/* Main Footer Content */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-8">
          {/* Practice Info */}
          <div className="space-y-6">
            <div>
              <h3 className="text-2xl font-bold text-white mb-2">M-Dental</h3>
              <p className="text-gray-300 mb-4">Professional Dental Care</p>
              <div className="flex items-center gap-1 mb-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star key={star} className="h-4 w-4 text-yellow-400 fill-current" />
                ))}
                <span className="text-sm text-gray-300 ml-2">Trusted Care</span>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-gray-300">
                <Award className="h-4 w-4 text-blue-400" />
                <span className="text-sm">5+ Years Experience</span>
              </div>
              <div className="flex items-center gap-2 text-gray-300">
                <Shield className="h-4 w-4 text-blue-400" />
                <span className="text-sm">Professional Care</span>
              </div>
              <div className="flex items-center gap-2 text-gray-300">
                <Heart className="h-4 w-4 text-red-400" />
                <span className="text-sm">Patient-Centered Approach</span>
              </div>
            </div>
          </div>

          {/* Contact Information */}
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-white">Contact Information</h4>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-blue-400 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-gray-300">Rruga 102, Bogovinje 1220</p>
                  <p className="text-gray-300">North Macedonia</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-blue-400 flex-shrink-0" />
                <a 
                  href="tel:+38970666254" 
                  className="text-gray-300 hover:text-blue-400 transition-colors"
                >
                  +389 70 666 254
                </a>
              </div>
              
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-blue-400 flex-shrink-0" />
                <a 
                  href="mailto:Rilind.r@m-dental.online" 
                  className="text-gray-300 hover:text-blue-400 transition-colors"
                >
                  Rilind.r@m-dental.online
                </a>
              </div>
            </div>
          </div>

          {/* Working Hours */}
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-white">Working Hours</h4>
            <div className="space-y-3">
              <div className="flex items-center gap-3 mb-4">
                <Clock className="h-5 w-5 text-blue-400" />
                <span className="text-gray-300">Schedule</span>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-300">Monday - Friday</span>
                  <span className="text-white font-semibold">9:00 - 19:00</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Saturday</span>
                  <span className="text-red-400">Closed</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Sunday</span>
                  <span className="text-red-400">Closed</span>
                </div>
              </div>
              
              <div className="mt-4 p-3 bg-blue-900 rounded-lg">
                <p className="text-blue-100 text-sm">
                  <strong>Emergency Care:</strong> Call us anytime for urgent dental issues
                </p>
              </div>
            </div>
          </div>

          {/* Our Doctors */}
          <div className="space-y-6">
            <h4 className="text-lg font-semibold text-white">Our Doctors</h4>
            <div className="space-y-4">
              <Card className="bg-gray-800 border-gray-700">
                <div className="p-4">
                  <h5 className="font-semibold text-white mb-1">DR. Rilind Ramadani</h5>
                  <p className="text-sm text-gray-300 mb-2">General Dentistry & Oral Surgery</p>
                  <div className="text-xs text-blue-400">5+ Years Experience</div>
                </div>
              </Card>
              
              <Card className="bg-gray-800 border-gray-700">
                <div className="p-4">
                  <h5 className="font-semibold text-white mb-1">DR. Mevlude R. Nuredini</h5>
                  <p className="text-sm text-gray-300 mb-2">Restorative Dentistry & Endodontics</p>
                  <div className="text-xs text-blue-400">5+ Years Experience</div>
                </div>
              </Card>
            </div>
            
            <Button 
              className="w-full bg-blue-600 hover:bg-blue-700"
              onClick={() => document.getElementById('appointment')?.scrollIntoView({ behavior: 'smooth' })}
            >
              Book Appointment
            </Button>
          </div>
        </div>
      </div>

      {/* Bottom Footer */}
      <div className="border-t border-gray-800">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-center md:text-left">
              <p className="text-gray-400 text-sm">
                © {currentYear} M-Dental. All rights reserved.
              </p>
              <p className="text-gray-500 text-xs mt-1">
                Professional dental care in Bogovinje, North Macedonia
              </p>
            </div>
            
            <div className="flex flex-col md:flex-row items-center gap-4 text-sm">
              <div className="flex items-center gap-2 text-gray-400">
                <Heart className="h-4 w-4 text-red-400" />
                <span>Caring for your smile since 2019</span>
              </div>
              
              <div className="flex gap-4">
                <button 
                  onClick={() => window.open('tel:+38970666254')}
                  className="text-gray-400 hover:text-blue-400 transition-colors text-xs"
                >
                  Emergency Call
                </button>
                <button 
                  onClick={() => window.open('https://maps.google.com/?q=Rruga+102,+Bogovinje+1220,+North+Macedonia', '_blank')}
                  className="text-gray-400 hover:text-blue-400 transition-colors text-xs"
                >
                  Directions
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}