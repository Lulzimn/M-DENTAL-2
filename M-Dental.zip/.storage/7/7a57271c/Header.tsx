import { Button } from '@/components/ui/button';
import { Phone, Mail, Clock } from 'lucide-react';

export default function Header() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      {/* Top bar with contact info */}
      <div className="bg-blue-600 text-white py-2">
        <div className="container mx-auto px-4 flex flex-wrap justify-between items-center text-sm">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <Phone className="h-4 w-4" />
              <span>+389 70 666 254</span>
            </div>
            <div className="flex items-center gap-1">
              <Mail className="h-4 w-4" />
              <span>Rilind.r@m-dental.online</span>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            <span>Mon-Fri: 9:00-19:00</span>
          </div>
        </div>
      </div>

      {/* Main navigation */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-blue-600">M-Dental</h1>
            <span className="ml-2 text-gray-600 text-sm">Professional Dental Care</span>
          </div>
          
          <nav className="hidden md:flex items-center space-x-6">
            <button 
              onClick={() => scrollToSection('home')}
              className="text-gray-700 hover:text-blue-600 transition-colors"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection('doctors')}
              className="text-gray-700 hover:text-blue-600 transition-colors"
            >
              Our Doctors
            </button>
            <button 
              onClick={() => scrollToSection('services')}
              className="text-gray-700 hover:text-blue-600 transition-colors"
            >
              Services
            </button>
            <button 
              onClick={() => scrollToSection('contact')}
              className="text-gray-700 hover:text-blue-600 transition-colors"
            >
              Contact
            </button>
            <Button 
              onClick={() => scrollToSection('appointment')}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Book Appointment
            </Button>
          </nav>

          {/* Mobile menu button */}
          <Button 
            variant="outline" 
            size="sm" 
            className="md:hidden"
            onClick={() => scrollToSection('appointment')}
          >
            Book Now
          </Button>
        </div>
      </div>
    </header>
  );
}