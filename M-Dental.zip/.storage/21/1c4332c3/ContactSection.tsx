import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Navigation,
  MessageCircle,
  Globe
} from 'lucide-react';

export default function ContactSection() {
  const contactInfo = [
    {
      icon: <MapPin className="h-6 w-6" />,
      title: "Our Location",
      details: [
        "Rruga 102, Bogovinje 1220",
        "North Macedonia"
      ],
      action: {
        text: "Get Directions",
        href: "https://maps.google.com/?q=Rruga+102,+Bogovinje+1220,+North+Macedonia"
      }
    },
    {
      icon: <Phone className="h-6 w-6" />,
      title: "Phone Number",
      details: [
        "+389 70 666 254"
      ],
      action: {
        text: "Call Now",
        href: "tel:+38970666254"
      }
    },
    {
      icon: <Mail className="h-6 w-6" />,
      title: "Email Address",
      details: [
        "Rilind.r@m-dental.online"
      ],
      action: {
        text: "Send Email",
        href: "mailto:Rilind.r@m-dental.online"
      }
    },
    {
      icon: <Clock className="h-6 w-6" />,
      title: "Working Hours",
      details: [
        "Monday - Friday: 9:00 - 19:00",
        "Saturday - Sunday: Closed"
      ],
      action: null
    }
  ];

  return (
    <section id="contact" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Get In Touch</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We're here to help you with all your dental needs. Contact us today to schedule 
            your appointment or ask any questions about our services.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Information */}
          <div className="space-y-6">
            <div className="grid gap-6">
              {contactInfo.map((info, index) => (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600 flex-shrink-0">
                        {info.icon}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900 mb-2">{info.title}</h3>
                        <div className="space-y-1">
                          {info.details.map((detail, detailIndex) => (
                            <p key={detailIndex} className="text-gray-600">{detail}</p>
                          ))}
                        </div>
                        {info.action && (
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="mt-3"
                            onClick={() => window.open(info.action.href, '_blank')}
                          >
                            {info.action.text}
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Quick Actions */}
            <Card className="bg-gradient-to-br from-blue-600 to-blue-700 text-white">
              <CardHeader>
                <CardTitle className="text-white">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  variant="secondary" 
                  className="w-full justify-start"
                  onClick={() => document.getElementById('appointment')?.scrollIntoView({ behavior: 'smooth' })}
                >
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Book Appointment Online
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start bg-transparent border-white text-white hover:bg-white hover:text-blue-600"
                  onClick={() => window.open('tel:+38970666254')}
                >
                  <Phone className="h-4 w-4 mr-2" />
                  Call Us
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start bg-transparent border-white text-white hover:bg-white hover:text-blue-600"
                  onClick={() => window.open('https://maps.google.com/?q=Rruga+102,+Bogovinje+1220,+North+Macedonia', '_blank')}
                >
                  <Navigation className="h-4 w-4 mr-2" />
                  Get Directions
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Map and Additional Info */}
          <div className="space-y-6">
            {/* Map Placeholder */}
            <Card className="overflow-hidden">
              <CardContent className="p-0">
                <div className="bg-gradient-to-br from-blue-100 to-blue-200 h-64 flex items-center justify-center relative">
                  <div className="text-center">
                    <MapPin className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                    <h3 className="text-xl font-bold text-gray-900 mb-2">Find Us Here</h3>
                    <p className="text-gray-600 mb-4">Rruga 102, Bogovinje 1220<br />North Macedonia</p>
                    <Button 
                      onClick={() => window.open('https://maps.google.com/?q=Rruga+102,+Bogovinje+1220,+North+Macedonia', '_blank')}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      <Navigation className="h-4 w-4 mr-2" />
                      Open in Maps
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Practice Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5 text-blue-600" />
                  About M-Dental Practice
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600">
                  Located in the heart of Bogovinje, M-Dental provides comprehensive dental care 
                  with a team of experienced professionals dedicated to your oral health.
                </p>
                
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">5+</div>
                    <div className="text-sm text-gray-600">Years Experience</div>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">2</div>
                    <div className="text-sm text-gray-600">Expert Doctors</div>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Our Commitment</h4>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Professional and caring dental treatment</li>
                    <li>• Modern equipment and techniques</li>
                    <li>• Comfortable and welcoming environment</li>
                    <li>• Personalized care for every patient</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}